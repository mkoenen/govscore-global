i18n_dict = {
    "Example 1"               : "Hallo!",
    
  };

  i18n_dict_fr = {
    "Example 1"               : "Salut!",
    
  };

  i18n_dict_en = {
    "Example 1"               : "Hello!",
    
  };